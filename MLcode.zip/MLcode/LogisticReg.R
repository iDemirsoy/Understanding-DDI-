### logistic regression 


setwd("/Users/idemirsoy/Library/CloudStorage/GoogleDrive-idris.demirsoy@usak.edu.tr/My Drive/DDIdata")
library(dplyr)

NameOrd=c("PathtcIDF", "MedSim","ATCsim","DiseaseSim","ProteinSim","EnzymeSim" )

DB00176=read.csv("CSVfiles/DB00176/Fluvoxamine.csv",header=T,sep=",")%>%select(-X) 
DB00196=read.csv("CSVfiles/DB00196/fluconazole.csv",header=T,sep=",")%>%select(-X) 
DB00208=read.csv("CSVfiles/DB00208/Ticlopidine.csv",header=T,sep=",")%>%select(-X)
DB00264=read.csv("CSVfiles/DB00264/Metoprolol.csv",header=T,sep=",")%>%select(-X)
DB00321=read.csv("CSVfiles/DB00321/Amitriptyline.csv",header=T,sep=",")%>%select(-X)
names(DB00321)[names(DB00321)=="drug_1.x"]=c("drug_1")
DB00335=read.csv("CSVfiles/DB00335/Atenolol.csv",header=T,sep=",")%>%select(-X)
DB00338=read.csv("CSVfiles/DB00338/Omeprazole.csv",header=T,sep=",")%>%select(-X)
DB00458=read.csv("CSVfiles/DB00458/Imipramine.csv",header=T,sep=",")%>%select(-X)
names(DB00458)[names(DB00458)=="drug_1.x"]=c("drug_1")
DB00472=read.csv("CSVfiles/DB00472/Fluoxetine.csv",header=T,sep=",")%>%select(-X)
DB00540=read.csv("CSVfiles/DB00540/Nortriptyline.csv",header=T,sep=",")%>%select(-X)
DB00582=read.csv("CSVfiles/DB00582/Voriconazole.csv",header=T,sep=",")%>%select(-X)  ### 351 - 0
names(DB00582)[names(DB00582)=="drug_1.x"]=c("drug_1")
DB00612=read.csv("CSVfiles/DB00612/Bisoprolol.csv",header=T,sep=",")%>%select(-X) 
DB00625=read.csv("CSVfiles/DB00625/Efavirenz.csv",header=T,sep=",")%>%select(-X)     ### might delete -- 224-0
names(DB00625)[names(DB00625)=="drug_1.x"]=c("drug_1")
DB00736=read.csv("CSVfiles/DB00736/Esomeprazole.csv",header=T,sep=",")               ### 673 - 0
names(DB00736)[names(DB00736)=="DiseaseSim.y"]=c("DiseaseSim")
DB00746=read.csv("CSVfiles/DB00746/Deferoxamine.csv",header=T,sep=",")%>%select(-X)  ### 838 - 0 
names(DB00746)[names(DB00746)=="drug_1.x"]=c("drug_1")
DB00758=read.csv("CSVfiles/DB00758/Clopidogrel.csv",header=T,sep=",")%>%select(-X)   ### 333 - 0 
names(DB00758)[names(DB00758)=="drug_1.x"]=c("drug_1")
DB00945=read.csv("CSVfiles/DB00945/Aspirin.csv",header=T,sep=",")%>%select(-X)  
DB01171=read.csv("CSVfiles/DB01171/Moclobemide.csv",header=T,sep=",")%>%select(-X)   ### 276 - 0
names(DB01171)[names(DB01171)=="drug_1.x"]=c("drug_1")
DB01242=read.csv("CSVfiles/DB01242/Clomipramine.csv",header=T,sep=",")%>%select(-X)    ## no Y in here 
DB01337=read.csv("CSVfiles/DB01337/Pancuronium.csv",header=T,sep=",")%>%select(-X)    ## no Y in here 
DB06414=read.csv("CSVfiles/DB06414/Etravirine.csv",header=T,sep=",")%>%select(-X)    ### 512 - 0
names(DB06414)[names(DB06414)=="drug_1.x"]=c("drug_1")
DB06605=read.csv("CSVfiles/DB06605/Apixaban.csv",header=T,sep=",")%>%select(-X)


AllIn1=rbind(DB00176,DB00196,DB00208,DB00264,DB00321,DB00335,DB00338,DB00458,DB00472,DB00540,DB00582,
             DB00612,DB00625,DB00736,DB00746,DB00758,DB00945,DB01171,DB01242,DB01337,DB06414,DB06605)

NoDub = AllIn1[!duplicated(t(apply(AllIn1[, 1:2], 1, sort))),] 
# AllIn1[!duplicated(cbind(pmin(AllIn1[,1], AllIn1[,2]), pmax(AllIn1[,1], AllIn1[,2]))),]  # both works 


names(NoDub)=c("drug_1","drug_2","Pathway", "MedDRA","MolSim","ATCsim","Target","Enzyme","PPIsim","Y","Disease" )
# 
## checking correlation 
num_features <- names(which(sapply(NoDub, is.numeric)))
Drug_num <- NoDub %>% as.data.frame %>% dplyr::select(num_features)%>%select(-Y)
CorMatrix <- cor(Drug_num)
library(corrplot)
corrplot(CorMatrix, method = "color", order = "AOE", addCoef.col="grey", addCoefasPercent = FALSE, number.cex = .7)

## creating custom validation set for presentation purpose  

ValidSet=rbind(
  NoDub[NoDub$drug_1=="DB00208" & NoDub$drug_2=="DB00945",],
  NoDub[NoDub$drug_1=="DB00945" & NoDub$drug_2=="DB00563",],
  NoDub[NoDub$drug_1=="DB00176" & NoDub$drug_2=="DB00682",],
  NoDub[NoDub$drug_1=="DB00176" & NoDub$drug_2=="DB00501",],
  NoDub[NoDub$drug_1=="DB00176" & NoDub$drug_2=="DB00679",],
  NoDub[NoDub$drug_1=="DB00338" & NoDub$drug_2=="DB00758",],
  NoDub[NoDub$drug_1=="DB00338" & NoDub$drug_2=="DB00582",],
  NoDub[NoDub$drug_1=="DB00458" & NoDub$drug_2=="DB00472",],
  NoDub[NoDub$drug_1=="DB01242" & NoDub$drug_2=="DB00501",]
)

## Remove Validation Set 
NoDubVal=setdiff(NoDub,ValidSet)

DrugData=NoDubVal%>%select(-c(drug_1,drug_2))

train_index <- sample(1:nrow(DrugData), 0.8 * nrow(DrugData))
test_index <- setdiff(1:nrow(DrugData), train_index)

# Build X_train, y_train, X_test, y_test
X_train <- DrugData[train_index,]
y_train <- DrugData[train_index, "Y"]

X_test <- DrugData[test_index, ]%>%select(-Y)
y_test <- DrugData[test_index, "Y"]


X_train$Y=factor(X_train$Y,levels=c(0,1))
fitLogistic=glm(Y~.,data=X_train,family="binomial")
summary(fitLogistic)

newdata1 <- predict(fitLogistic, newdata = X_test, type = "response")




y_pLogit=ifelse(newdata1<=0.5,0,1)
### Accuracy 
train_tab = table(actual = y_test, predicted = y_pLogit)
library(caret)
train_con_mat = confusionMatrix(train_tab, positive = "1")
c(train_con_mat$overall["Accuracy"], 
  train_con_mat$byClass["Sensitivity"], 
  train_con_mat$byClass["Specificity"],
  train_con_mat$byClass["F1"])


ValidTest=ValidSet%>%select(-c(drug_1,drug_2,Y))

## gives probability of interaction for saved file 
ValidTest$yPredLogistic <- predict(fitLogistic, ValidTest, type = "response")

ValidTest


## linearity check 

titanic <- X_train %>% 
  mutate(Path_ln = log(Pathway), MedDRA_ln = log(MedDRA), MolSim_ln = log(MolSim+0.0001),
         ATCsim_ln = log(ATCsim + 0.0001), Target_ln = log(Target), Enzyme_ln = log(Enzyme),
         PPIsim_ln = log(PPIsim),Disease_ln = log(Disease+0.0001), ATC2=log(ATCsim+0.0001), Disease2=Disease^2, 
         Target2=Target^2, Enzyme2=Enzyme^2)



#titanic2 = titanic %>%  
#  mutate(Pathway_mut=Pathway*Path_ln , MedDRA_mut=MedDRA*MedDRA_ln , ATCsim_mut=ATCsim*ATCsim_ln , 
#           Target_mut=Target*Target_ln ,  Enzyme_mut=Enzyme*Enzyme_ln , PPIsim_mut=PPIsim*PPIsim_ln ,
#           Disease_mut=Disease*Disease_ln , MolSim_mut=MolSim*MolSim_ln )


fitl2=glm(Y~ Pathway + MedDRA + MolSim  + ATC2 + Target2 + Enzyme2 + PPIsim + Disease2,
          data=titanic,family="binomial")
summary(fitl2)


X2_t2 <- X_test %>% 
  mutate(ATC2=log(ATCsim+0.0001), Disease2=Disease^2, Target2=Target^2, Enzyme2=Enzyme^2)


new2 <- predict(fitl2, newdata = X2_t2, type = "response")



y_pLogit2=ifelse(new2<=0.5,0,1)
### Accuracy 
train_tab2 = table(actual = y_test, predicted = y_pLogit2)
train_tab2
library(caret)
train_con_mat2 = confusionMatrix(train_tab2, positive = "1")
c(train_con_mat2$overall["Accuracy"], 
  train_con_mat2$byClass["Sensitivity"], 
  train_con_mat2$byClass["Specificity"],
  train_con_mat2$byClass["F1"])


# https://onlineconfusionmatrix.com/ 

install.packages("fmsb")
library(fmsb)

NagelkerkeR2(fitl2)

# Table 3 

anova(fitl2)


# cohen's kappa 

# Contingency table
xtab <- as.table(rbind(c(2047, 197), c(947, 457)))
# Descriptive statistics
diagonal.counts <- diag(xtab)
N <- sum(xtab)
row.marginal.props <- rowSums(xtab)/N
col.marginal.props <- colSums(xtab)/N
# Compute kappa (k)
Po <- sum(diagonal.counts)/N
Pe <- sum(row.marginal.props*col.marginal.props)
k <- (Po - Pe)/(1 - Pe)
k





