### Neural Net 
##  https://keras.rstudio.com/
## https://tensorflow.rstudio.com/installation/

#devtools::install_github("rstudio/tensorflow")
library(tensorflow)
#install_tensorflow()

#install.packages("keras")
library(keras)

### logistic regression 

setwd("C:/Users/idemirsoy/Desktop/PvSummerCodes/")
library(dplyr)

NameOrd=c("PathtcIDF", "MedSim","ATCsim","DiseaseSim","ProteinSim","EnzymeSim" )

DB00176=read.csv("CSVfiles/DB00176/Fluvoxamine.csv",header=T,sep=",")%>%select(-X) 
DB00196=read.csv("CSVfiles/DB00196/fluconazole.csv",header=T,sep=",")%>%select(-X) 
DB00208=read.csv("CSVfiles/DB00208/Ticlopidine.csv",header=T,sep=",")%>%select(-X)
DB00321=read.csv("CSVfiles/DB00321/Amitriptyline.csv",header=T,sep=",")%>%select(-X)
names(DB00321)[names(DB00321)=="drug_1.x"]=c("drug_1")
DB00338=read.csv("CSVfiles/DB00338/Omeprazole.csv",header=T,sep=",")%>%select(-X)
DB00458=read.csv("CSVfiles/DB00458/Imipramine.csv",header=T,sep=",")%>%select(-X)
names(DB00458)[names(DB00458)=="drug_1.x"]=c("drug_1")
DB00472=read.csv("CSVfiles/DB00472/Fluoxetine.csv",header=T,sep=",")%>%select(-X)
DB00582=read.csv("CSVfiles/DB00582/Voriconazole.csv",header=T,sep=",")%>%select(-X)  ### 351 - 0
names(DB00582)[names(DB00582)=="drug_1.x"]=c("drug_1")
DB00625=read.csv("CSVfiles/DB00625/Efavirenz.csv",header=T,sep=",")%>%select(-X)     ### might delete -- 224-0
names(DB00625)[names(DB00625)=="drug_1.x"]=c("drug_1")
DB00736=read.csv("CSVfiles/DB00736/Esomeprazole.csv",header=T,sep=",")               ### 673 - 0
names(DB00736)[names(DB00736)=="DiseaseSim.y"]=c("DiseaseSim")
DB00746=read.csv("CSVfiles/DB00746/Deferoxamine.csv",header=T,sep=",")%>%select(-X)  ### 838 - 0 
names(DB00746)[names(DB00746)=="drug_1.x"]=c("drug_1")
DB00758=read.csv("CSVfiles/DB00758/Clopidogrel.csv",header=T,sep=",")%>%select(-X)   ### 333 - 0 
names(DB00758)[names(DB00758)=="drug_1.x"]=c("drug_1")
DB00945=read.csv("CSVfiles/DB00945/Aspirin.csv",header=T,sep=",")%>%select(-X)  
DB01171=read.csv("CSVfiles/DB01171/Moclobemide.csv",header=T,sep=",")%>%select(-X)   ### 276 - 0
names(DB01171)[names(DB01171)=="drug_1.x"]=c("drug_1")
DB01242=read.csv("CSVfiles/DB01242/Clomipramine.csv",header=T,sep=",")%>%select(-X)    ## no Y in here 
DB01337=read.csv("CSVfiles/DB01337/Pancuronium.csv",header=T,sep=",")%>%select(-X)    ## no Y in here 
DB06414=read.csv("CSVfiles/DB06414/Etravirine.csv",header=T,sep=",")%>%select(-X)    ### 512 - 0
names(DB06414)[names(DB06414)=="drug_1.x"]=c("drug_1")
DB06605=read.csv("CSVfiles/DB06605/Apixaban.csv",header=T,sep=",")%>%select(-X)


AllIn1=rbind(DB00176,DB00196,DB00208,DB00321,DB00338,DB00458,DB00472,DB00582,DB00625,DB00736,DB00746,DB00758,DB00945,DB01171,DB01242,DB01337,DB06414,DB06605)

NoDub = AllIn1[!duplicated(t(apply(AllIn1[, 1:2], 1, sort))),] 
# AllIn1[!duplicated(cbind(pmin(AllIn1[,1], AllIn1[,2]), pmax(AllIn1[,1], AllIn1[,2]))),]  # both works 


names(NoDub)=c("drug_1","drug_2","Pathway", "MedDRA","MolSim","ATCsim","Target","Enzyme","PPIsim","Y","Disease" )
# 
## checking correlation 
num_features <- names(which(sapply(NoDub, is.numeric)))
Drug_num <- NoDub %>% as.data.frame %>% dplyr::select(num_features)%>%select(-Y)
CorMatrix <- cor(Drug_num)
library(corrplot)
corrplot(CorMatrix, method = "color", order = "AOE", addCoef.col="grey", addCoefasPercent = FALSE, number.cex = .7)

## creating custom validation set for presentation purpose  

ValidSet=rbind(
  NoDub[NoDub$drug_1=="DB00208" & NoDub$drug_2=="DB00945",],
  NoDub[NoDub$drug_1=="DB00945" & NoDub$drug_2=="DB00563",],
  NoDub[NoDub$drug_1=="DB00176" & NoDub$drug_2=="DB00682",],
  NoDub[NoDub$drug_1=="DB00176" & NoDub$drug_2=="DB00501",],
  NoDub[NoDub$drug_1=="DB00176" & NoDub$drug_2=="DB00679",],
  NoDub[NoDub$drug_1=="DB00338" & NoDub$drug_2=="DB00758",],
  NoDub[NoDub$drug_1=="DB00338" & NoDub$drug_2=="DB00582",],
  NoDub[NoDub$drug_1=="DB00458" & NoDub$drug_2=="DB00472",],
  NoDub[NoDub$drug_1=="DB01242" & NoDub$drug_2=="DB00501",]
)

## Remove Validation Set 
NoDubVal=setdiff(NoDub,ValidSet)

DrugData=NoDubVal%>%select(-c(drug_1,drug_2))

DrugDataScaled=scale(DrugData[-8])

train_indexSVM <- sample(1:nrow(DrugDataScaled), 0.8 * nrow(DrugDataScaled))
test_indexSVM <- setdiff(1:nrow(DrugDataScaled), train_indexSVM)

# Build X_train, y_train, X_test, y_test
X_trainSVM <- DrugDataScaled[train_indexSVM,]
y_trainSVM <- DrugData[train_indexSVM, "Y"]
XX_train=data.frame(X_trainSVM,y_trainSVM)

X_testSVM <- DrugDataScaled[test_indexSVM, ]
y_testSVM <- DrugData[test_indexSVM, "Y"]

d=-log(sum(y_trainSVM==0)/sum(y_trainSVM==1))

l2_model <-
  keras_model_sequential() %>%
  layer_dense(units = 128, activation = "relu", input_shape =  ncol(X_trainSVM),
             bias_initializer = initializer_glorot_normal()) %>%
  layer_dropout(rate=0.4)%>%
  layer_dense(units = 64, activation = "relu" ) %>%
  layer_dense(units = 8, activation = "relu" ) %>%
  layer_dense(units = 1, activation = "sigmoid"  ,
              bias_initializer = initializer_constant(d))

l2_model %>% compile(
  optimizer= optimizer_adam(lr = 0.01,decay=0.0009),
  loss = "binary_crossentropy",
  metrics =  c('accuracy')
)
#   
summary(l2_model)

l2_history <- l2_model %>% fit(
  x                = as.matrix(X_trainSVM),
  y                = y_trainSVM,
  epochs = 50,
  batch_size = 10,
  validation_data = list(X_testSVM, y_testSVM),
  verbose = 2,
  callbacks = list(
    callback_early_stopping(patience = 5))
)


yhat_keras_prob_vec  <- predict_proba(object = l2_model, x = as.matrix(X_testSVM)) %>% as.matrix()


y_predNN=ifelse(yhat_keras_prob_vec<=0.5,0,1)
### Accuracy 
train_tab = table(actual = y_testSVM, predicted = y_predNN)
library(caret)
train_con_mat = confusionMatrix(train_tab, positive = "1")
c(train_con_mat$overall["Accuracy"], 
  train_con_mat$byClass["Sensitivity"], 
  train_con_mat$byClass["Specificity"],
  train_con_mat$byClass["F1"])


ValidTest=ValidSet%>%select(-c(drug_1,drug_2,Y))

ValidSet$yPredNN <- predict(l2_model, as.matrix(ValidTest))

ValidSet


